﻿using UnityEngine;
using System.Collections;

public class LeaderBoardTest : MonoBehaviour
{
    private IPostScores postScores;
	
    public int score = 1;
    public string name = string.Empty;

    void Awake()
    {
        //this.postScores = new PostScoresLeaderBoard("lbexample", "http://130.206.83.3:4567/lb/");
        this.postScores = new PostScoresLeaderBoard();
    }
    
    [ContextMenu("get scores")]
    void GetScores()
    {
        foreach (var score in postScores.GetScores())
            Debug.Log(score.ToString());
    }

    [ContextMenu("post score")]
    void PostScore()
    {
        Debug.Log (postScores.PostScores(new Score(this.name, this.score)));
    }
}
